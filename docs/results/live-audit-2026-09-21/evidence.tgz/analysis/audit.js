'use strict';
const fs=require('node:fs'),path=require('node:path');
const ROOT=process.env.ARENA_CODE_ROOT || require('node:path').resolve(__dirname,'../reviewed-runtime');
const sim=require(ROOT+'/lib/sim'),shop=require(ROOT+'/lib/shop_model'),bookLib=require(ROOT+'/lib/book'),target=require(ROOT+'/lib/target'),planner=require(ROOT+'/lib/planner'),catalog=require(ROOT+'/lib/catalog');
const archive=path.resolve(__dirname,'../thursday-arena'),before=path.resolve(__dirname,'../thursday-arena.backup-reviewed-20260920-221919');
const events=fs.readFileSync(archive+'/data/log/2026-09-21.jsonl','utf8').trim().split('\n').map(JSON.parse).filter(e=>e.session==='5fc6e525-3641-4d0e-b9fd-33bde5311ae3');
const matches=new Map();
for(const e of events){if(!e.matchKey)continue;let m=matches.get(e.matchKey);if(!m){m={key:e.matchKey,events:[]};matches.set(e.matchKey,m);}m.events.push(e);if(e.type==='match_start')m.start=e;if(e.type==='result'){m.result=e;m.detail=JSON.parse(fs.readFileSync(path.join(__dirname,'public',e.matchId+'.json'),'utf8'));}if(e.type==='battle')(m.battles||=[]).push(e);}
const book=bookLib.open(before+'/memory/book.json',{now:()=>Date.parse(events[0].ts)});
const observations=[],shopRows=[],battleRows=[],sourceMismatches=[],duplicates=[];
const outcome=(x)=>x==='us'?'you':x;
const score=(x)=>x==='you'||x==='us'?1:x==='draw'?.5:0;
function normalizedShop(e){return {round:e.round,gold:e.gold,board:e.board,offers:e.offers,frozen:e.offers.map(o=>!!o?.frozen),food:e.food,series:e.series,seats:e.seats,season:e.season,captain:e.captain||null,rivalCaptain:e.rivalCaptain||null,captainOffer:null,carry:e.carry||0,freeRerolls:e.freeRerolls??null,shopCosts:e.shopCosts||null,itemOffer:e.itemOffer||null,rerolls:e.rerolls||0,pendingBuff:null,nextUid:Math.max(0,...e.board.map(u=>u.uid||0))+1};}
const stateByRound=new Map(),entryByRound=new Map();
for(const e of events){const m=matches.get(e.matchKey);if(!m)continue;const k=e.matchKey+':'+e.round;
 if(e.type==='shop'){
  const S=normalizedShop(e);stateByRound.set(k,S);
  const opts={book,season:e.season,round:e.round,handle:e.handle,prevHandle:m.start.prevHandle,seats:e.seats};
  const T=target.build(opts);if(JSON.stringify(T.sources)!==JSON.stringify({bookN:e.target.bookN,poolN:e.target.poolN,bookWeight:e.target.bookWeight}))sourceMismatches.push({match:e.matchKey,round:e.round,expected:e.target,got:T.sources});
  const row={matchKey:m.key,matchId:m.result?.matchId,round:e.round,season:e.season,handle:e.handle,opponent:m.result?.opponent,ts:e.ts,state:S,target:T,prevHandle:m.start.prevHandle,observedResult:m.result?.result,bookCandidates:book.lookup(e.season,e.round===0?(e.handle||m.start.prevHandle):e.handle,e.round),bookObservations:book.stats().observations};
  entryByRound.set(k,row);shopRows.push(row);
 }
 if(e.type==='act'&&e.accepted&&e.after&&e.afterPhase==='shop')stateByRound.set(k,e.after);
 if(e.type==='act'&&e.action?.type==='endShop'&&e.accepted){const row=entryByRound.get(k);if(row){row.finalState=stateByRound.get(k);row.goldLeft=e.goldLeft;}}
 if(e.type==='battle'){
  const row=entryByRound.get(k);if(row)row.battle=e;
  if(e.season>=3&&m.detail){const r=m.detail.rounds.find(r=>r.round===e.round);if(!r)throw Error('missing public round');
   const opts={season:3,round:e.round,seats:e.seats,ourCaptain:e.captain,theirCaptain:e.rivalCaptain};const us=r.you.map(u=>catalog.toSimUnit(u,3)),them=r.them.map(u=>catalog.toSimUnit(u,3));
   const got=sim.simulate(us,them,opts);let at=0;while(at<Math.max(got.frames.length,e.frames.length)&&JSON.stringify(got.frames[at])===JSON.stringify(e.frames[at]))at++;
   const exact=at===got.frames.length&&at===e.frames.length;
   const ranked=sim.bestSeating(us,[{board:them,weight:1}],{...opts,utility:{win:1,draw:.5,loss:0}});
   const br={matchKey:m.key,matchId:m.result.matchId,round:e.round,opponent:m.result.opponent,result:m.result.result,winner:e.winner,simWinner:outcome(got.winner),framesExact:exact,frameDifference:exact?null:{at,got:got.frames[at]?.caption,expected:e.frames[at]?.caption},ourInputMatches:JSON.stringify(bookLib.normBoard(us))===JSON.stringify(bookLib.normBoard(e.us)),publicFramesMatch:JSON.stringify(r.frames)===JSON.stringify(e.frames),us,them,opts,bestSeatScore:ranked[0]?.score,bestSeatOrder:ranked[0]?.order};
   if(row){br.finalState=row.finalState;br.target=row.target;row.exactThem=them;row.simOptions=opts;row.framesExact=exact;row.actualUnits=us;row.battleResult=e.winner;}
   battleRows.push(br);
  }
  if(e.season<3&&e.them?.length){const obs={season:e.season,handle:e.handle,round:e.round,board:e.them,seats:e.seats,matchId:e.matchId,ts:e.ts};book.record(obs);observations.push(obs);}
 }
 if(e.type==='book'){
  const b=m.battles.find(b=>b.round===e.round);const r=m.detail?.rounds.find(r=>r.round===e.round);
  const obs={season:3,handle:m.result?.opponent||m.battles.find(b=>b.handle)?.handle||m.events.find(x=>x.type==='shop'&&x.handle)?.handle,round:e.round,board:e.source==='public_replay'?bookLib.publicReplayBoard(r,'them'):b.them,seats:b.seats,matchId:m.result?.matchId||b.matchId,captain:b.rivalCaptain,ts:b.ts};
  if(!obs.handle)throw Error('no handle for '+k);book.record(obs);observations.push({...obs,source:e.source});
 }
}
const actual=bookLib.open(archive+'/memory/book.json');const canonical=b=>Object.fromEntries(Object.entries(b.data().entries).map(([k,rows])=>[k,rows.map(r=>({k:bookLib.boardKey(r.board,r.captain),n:r.n})).sort((a,b)=>a.k.localeCompare(b.k))]));
const expected=canonical(book),stored=canonical(actual);const memoryDiff=Object.keys({...expected,...stored}).filter(k=>JSON.stringify(expected[k])!==JSON.stringify(stored[k])).map(k=>({key:k,expected:expected[k],actual:stored[k]}));
const complete=[...matches.values()].filter(m=>m.result&&m.start.season===3);const counts=rows=>rows.reduce((a,m)=>{const r=m.result.result;a[r]=(a[r]||0)+1;return a;},{});
const byOpponent={};for(const m of complete){const x=byOpponent[m.result.opponent]||(byOpponent[m.result.opponent]={win:0,loss:0,draw:0});x[m.result.result]++;}
const phases=[];for(let i=0;i<complete.length;i+=25)phases.push({from:i+1,to:Math.min(i+25,complete.length),...counts(complete.slice(i,i+25))});
const repeat=complete.filter(m=>m.result.opponent.toLowerCase()===m.start.prevHandle?.toLowerCase());
const short=shopRows.filter(r=>r.season>=3&&r.finalState&&r.finalState.board.length<3).map(r=>({matchId:r.matchId,round:r.round,gold:r.goldLeft,n:r.finalState.board.length}));
const summary={code:events[0].code,session:events[0].session,start:events[0].ts,end:events.at(-1).ts,totalResultRows:[...matches.values()].filter(m=>m.result).length,fullS3Matches:complete.length,results:counts(complete),eloS3:complete.reduce((a,m)=>a+m.result.eloDelta,0),opponents:Object.keys(byOpponent).length,byOpponent,phases,previousOpponentRepeats:repeat.length,completeS3Battles:battleRows.length,simWinnerMatches:battleRows.filter(r=>r.winner===r.simWinner).length,frameMatches:battleRows.filter(r=>r.framesExact).length,ourInputMatches:battleRows.filter(r=>r.ourInputMatches).length,publicFrameMatches:battleRows.filter(r=>r.publicFramesMatch).length,sourceMismatches,memoryMismatches:memoryDiff,bookBefore:bookLib.open(before+'/memory/book.json').stats(),bookAfter:actual.stats(),newS3Writes:observations.filter(o=>o.season===3).length,shortBoards:short,seatRescues:battleRows.filter(r=>r.framesExact&&r.bestSeatScore>score(r.winner)).map(r=>({matchId:r.matchId,round:r.round,opponent:r.opponent,result:r.result,winner:r.winner,bestSeatScore:r.bestSeatScore})),frameDifferences:battleRows.filter(r=>!r.framesExact).map(({target,finalState,us,them,bestSeatOrder,...r})=>r)};
fs.writeFileSync(path.join(__dirname,'audit-summary.json'),JSON.stringify(summary,null,2));fs.writeFileSync(path.join(__dirname,'shop-rows.json'),JSON.stringify(shopRows));fs.writeFileSync(path.join(__dirname,'battle-rows.json'),JSON.stringify(battleRows));fs.writeFileSync(path.join(__dirname,'observations.json'),JSON.stringify(observations));
console.log(JSON.stringify({...summary,byOpponent:undefined,memoryMismatches:memoryDiff.length,sourceMismatches:sourceMismatches.length,frameDifferences:summary.frameDifferences.map(r=>({matchId:r.matchId,round:r.round,winner:r.winner,simWinner:r.simWinner,...r.frameDifference}))},null,2));
