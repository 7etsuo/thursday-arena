'use strict';
const fs=require('fs'),{isDeepStrictEqual}=require('util');const ROOT=process.env.ARENA_CODE_ROOT || require('node:path').resolve(__dirname,'../reviewed-runtime');
const shop=require(ROOT+'/lib/shop_model'),sim=require(ROOT+'/lib/sim'),planner=require(ROOT+'/lib/planner'),book=require(ROOT+'/lib/book');
const rows=require('./shop-rows.json').filter(r=>r.season===3&&r.matchId&&r.battle),battles=require('./battle-rows.json');
const events=fs.readFileSync(__dirname+'/../thursday-arena/data/log/2026-09-21.jsonl','utf8').trim().split('\n').map(JSON.parse).filter(e=>e.session==='5fc6e525-3641-4d0e-b9fd-33bde5311ae3');
const SMap=new Map(rows.map(r=>[r.matchKey+':'+r.round,r.state]));let checks=0,goldChecks=0;const modelErrors=[];
for(const e of events){const key=e.matchKey+':'+e.round;let S=SMap.get(key);if(!S||e.type!=='act'||!e.accepted||!e.after||e.afterPhase!=='shop')continue;const action=e.action;const next=e.after;
 if(action&&action.type!=='pickCaptain'){
  const legality=shop.legal(S,action);if(legality!==true)modelErrors.push({matchId:rows.find(r=>r.matchKey===e.matchKey)?.matchId,round:e.round,action,why:legality});
  else {const pred=shop.apply(S,action);goldChecks++;if(pred.gold!==next.gold)modelErrors.push({matchKey:e.matchKey,round:e.round,action,field:'gold',pred:pred.gold,actual:next.gold});
   if(action.type!=='reroll'){checks++;const ok=shop.simUnitsOutcomes(pred).some(w=>isDeepStrictEqual(w.units,shop.simUnits(next)));if(!ok)modelErrors.push({matchKey:e.matchKey,round:e.round,action,field:'board'});}
  }
 }
 SMap.set(key,next);
}
function boardKey(b){return book.boardKey(book.normBoard(b));}
const predictions=[];
for(const r of rows){const known=r.bookCandidates||[];const actual=boardKey(r.exactThem);const bk=known.map(k=>({...k,key:boardKey(k.board)}));const currentCap=r.state.rivalCaptain;
 const policies={frequency:bk,latest:bk.map(k=>({...k,n:k.lastTs===Math.max(...bk.map(x=>x.lastTs))?1:0})),captain:bk.filter(k=>k.captain===currentCap)};if(!policies.captain.length||!currentCap)policies.captain=bk;
 for(const mins of [1,5,15])policies['decay'+mins]=bk.map(k=>({...k,n:k.n*2**(-(Math.max(...bk.map(x=>x.lastTs))-k.lastTs)/(mins*60000))}));
 const probs={};for(const [p,ks] of Object.entries(policies)){const total=ks.reduce((s,k)=>s+k.n,0);const mass=ks.filter(k=>k.key===actual).reduce((s,k)=>s+k.n,0);const best=ks.length?ks.reduce((a,b)=>b.n>a.n?b:a):null;probs[p]={mass:total?mass/total:0,top:!!best&&best.key===actual};}
 predictions.push({matchId:r.matchId,round:r.round,opponent:r.opponent,known:known.length,covered:bk.some(k=>k.key===actual),captainKnown:!!currentCap,probs,matchResult:r.observedResult});
}
const pp={};for(const set of ['all','later','laterCovered','lossLater']){const rs=predictions.filter(r=>set==='all'||set==='later'?set==='all'||r.round>0:set==='laterCovered'?r.round>0&&r.covered:r.round>0&&r.matchResult==='loss');pp[set]={n:rs.length,hasBook:rs.filter(r=>r.known).length,covered:rs.filter(r=>r.covered).length,policies:{}};for(const p of ['frequency','latest','captain','decay1','decay5','decay15'])pp[set].policies[p]={topMatches:rs.filter(r=>r.probs[p].top).length,meanAssignedMass:rs.reduce((s,r)=>s+r.probs[p].mass,0)/rs.length};}
const rescues=[];let checked=0;
for(const r of rows){if(!r.framesExact||r.battle.winner==='you'||!r.finalState)continue;checked++;const baseline=planner.evaluate(r.actualUnits,[{board:r.exactThem,weight:1}],r.simOptions);let best=baseline.score,bestAction=null;
 for(const m of planner.singleMoves(r.finalState)){let st=r.finalState;for(const a of m.actions)st=shop.apply(st,a);let value=0;for(const w of shop.simUnitsOutcomes(st))value+=w.p*planner.evaluate(w.units,[{board:r.exactThem,weight:1}],r.simOptions).score;if(value>best){best=value;bestAction=m.actions;}}
 if(bestAction)rescues.push({matchId:r.matchId,round:r.round,opponent:r.opponent,matchResult:r.observedResult,winner:r.battle.winner,gold:r.finalState.gold,seatingOnly:baseline.score,bestOneMove:best,actions:bestAction});
}
const memoryByMatch={};for(const e of events)if(e.type==='book'){const r=rows.find(r=>r.matchKey===e.matchKey);if(r)(memoryByMatch[r.matchId]||(memoryByMatch[r.matchId]={result:r.observedResult,rounds:[]})).rounds.push(e.round);}
const result={deterministicBoardChecks:checks,economicChecks:goldChecks,modelErrors,predictionComparison:pp,hindsight:{note:'Uses the actual opponent to identify possible missed opportunities, not a deployable policy or proof of preventable match losses. Only observed frame-exact battles included.',nonWinningBattlesChecked:checked,oneMoveRescues:rescues},lossLearning:Object.entries(memoryByMatch).filter(([k,v])=>v.result==='loss').map(([matchId,v])=>({matchId,...v})),predictions};fs.writeFileSync(__dirname+'/decision-audit.json',JSON.stringify(result,null,2));console.log(JSON.stringify({...result,predictions:undefined},null,2));
