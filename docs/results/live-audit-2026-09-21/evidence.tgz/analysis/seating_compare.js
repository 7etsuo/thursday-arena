'use strict';const fs=require('fs');const ROOT=process.env.ARENA_CODE_ROOT || require('node:path').resolve(__dirname,'../reviewed-runtime'),sim=require(ROOT+'/lib/sim'),planner=require(ROOT+'/lib/planner'),book=require(ROOT+'/lib/book');
const rows=require('./shop-rows.json').filter(r=>r.season===3&&r.matchId&&r.battle&&r.framesExact);const score=w=>w==='us'||w==='you'?1:w==='draw'?.5:0;
const variants=['frequency','latest','captain','decay1'];const results=[];
for(const r of rows){const known=r.bookCandidates;const byKey=new Map(known.map(k=>[book.boardKey(k.board,k.captain),k]));const latest=Math.max(0,...known.map(k=>k.lastTs));const haveCaptain=r.state.rivalCaptain&&known.some(k=>k.captain===r.state.rivalCaptain);const result={matchId:r.matchId,round:r.round,opponent:r.opponent,matchResult:r.observedResult,actual:score(r.battle.winner),choices:{}};
 for(const variant of variants){const entries=r.target.entries.map(e=>{if(e.source!=='book'||variant==='frequency')return e;const k=byKey.get(book.boardKey(e.board,e.theirCaptain));if(!k)throw Error('missing book key');let w=e.weight;
  if(variant==='latest')w=k.lastTs===latest?1:0;
  if(variant==='captain'&&haveCaptain)w=k.captain===r.state.rivalCaptain?k.n:0;
  if(variant==='decay1')w=k.n*2**(-(latest-k.lastTs)/60000);
  return {...e,weight:w};});
  const oldMass=r.target.entries.filter(e=>e.source==='book').reduce((s,e)=>s+e.weight,0),mass=entries.filter(e=>e.source==='book').reduce((s,e)=>s+e.weight,0);for(const e of entries)if(e.source==='book')e.weight*=mass?oldMass/mass:0;
  const selected=planner.evaluate(r.actualUnits,entries,{season:3,round:r.round,seats:r.state.seats,ourCaptain:r.state.captain,theirCaptain:r.state.rivalCaptain,utility:planner.utility(r.round,r.state.series)});
  const actual=sim.outcome(selected.order,r.exactThem,r.simOptions);result.choices[variant]={score:score(actual),targetScore:selected.score,order:selected.order.map(u=>u.name)};
 }
 results.push(result);
}
const summaries={};for(const v of variants){const diff=results.map(r=>r.choices[v].score-r.choices.frequency.score);summaries[v]={rounds:results.length,totalScore:results.reduce((s,r)=>s+r.choices[v].score,0),improved:diff.filter(d=>d>0).length,worsened:diff.filter(d=>d<0).length,scoreChange:diff.reduce((a,b)=>a+b,0)};}
const out={note:'Seating-only counterfactual: hold played purchases/captain/boards fixed; choose using only historical targets available at each shop. Evaluate against the recorded opponent. Restricted to frame-exact battles. Not an end-to-end match win-rate estimate.',summaries,changed:results.filter(r=>variants.some(v=>r.choices[v].score!==r.choices.frequency.score)),results};fs.writeFileSync(__dirname+'/seating-comparison.json',JSON.stringify(out,null,2));console.log(JSON.stringify({summaries,changed:out.changed},null,2));
