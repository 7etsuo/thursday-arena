# Live audit evidence, 2026-09-21 UTC

This is an analysis dossier, not a bot installation package.

The complete original supplied archive remains in Downloads with SHA-256
`a249d36e5ea4b915f74fa0f49e5d54192456078c3ef98b75a3396e41d0e220e5`.
This dossier retains the inputs to the new-session audit, its intermediate data,
and the public replays downloaded for the audit. Older daily logs were inventoried
in inventory.json and remain in the original full archive.

The original reviewed library and catalog snapshot is in reviewed-runtime/.
Analysis scripts default to that snapshot. Set ARENA_CODE_ROOT to an absolute
repository path to inspect another version; reproducing historical memory decisions
requires using the original reviewed snapshot. Node 25 was used for this audit.
The only portability edit to the saved scripts is the default runtime path.

After extracting, run sequentially from this directory:

```sh
node analysis/audit.js
node analysis/decision_audit.js
node analysis/diagnose_sim.js
node analysis/seating_compare.js
node analysis/stop_audit.js
```

These commands are offline and overwrite analysis outputs in this extracted copy.
The simulator probe compiles diagnostic changes in memory; it does not write a
modified simulator. It is not a completed fix or a deployment.
`fetch_public.js` uses public network GET requests if any cached public files are
missing; running it is unnecessary because all 138 are already included.

The before/after remote books are evidence only. Do not merge them into a running
installation merely to reproduce this audit. The runtime checksum manifest covers
the full original application; this dossier's runtime snapshot includes only the
library and catalog files needed by the analysis scripts.
