'use strict';
const fs=require('fs'),ROOT=process.env.ARENA_AUDIT_RUNTIME||require('path').join(__dirname,'runtime');
const bookLib=require(ROOT+'/lib/book'),catalog=require(ROOT+'/lib/catalog');
const events=require('./events.json'),history=require('./public-history.json'),obs=require('./observations.json'),battles=require('./battle-rows.json');
const start='2026-09-21T07:17:54.651Z',end='2026-09-21T13:09:12.777Z';
const seen=new Set(),duplicates=[];for(const r of history){if(seen.has(r.id))duplicates.push(r.id);seen.add(r.id);}
const rows=history.filter(e=>e.played_at>=start).map(e=>({...e,us:e.players.find(p=>p.x_handle==='tetsuoai'),enemy:e.players.find(p=>p.x_handle!=='tetsuoai')}));
const count=rs=>({matches:rs.length,win:rs.filter(e=>e.us.outcome==='win').length,loss:rs.filter(e=>e.us.outcome==='loss').length,draw:rs.filter(e=>e.us.outcome==='draw').length,elo:rs.reduce((s,e)=>s+(e.us.elo_delta||0),0)});
function section(rs){const out={attacks:count(rs.filter(e=>e.us.role==='attacker')),defenses:count(rs.filter(e=>e.us.role==='ghost')),byOpponent:{}};for(const e of rs){const h=e.enemy.x_handle;out.byOpponent[h]||={attacks:[],defenses:[]};out.byOpponent[h][e.us.role==='attacker'?'attacks':'defenses'].push(e);}for(const h in out.byOpponent)for(const role in out.byOpponent[h])out.byOpponent[h][role]=count(out.byOpponent[h][role]);return out;}
const byId=new Map(rows.map(e=>[e.id,e])),logResults=events.filter(e=>e.type==='result'),logIds=new Set(logResults.map(e=>e.matchId));
const crosscheck=logResults.filter(e=>{const p=byId.get(e.matchId);return !p||p.us.outcome!==e.result||p.us.elo_delta!==e.eloDelta;});
const book=bookLib.open(require('path').join(__dirname,'initial-book.json'));
const bookTimes=new Map(events.filter(e=>e.type==='book').map(e=>[e.matchKey+':'+e.round,e.ts]));
const recorded=obs.map(o=>({...o,availableAt:bookTimes.get(o.matchKey+':'+o.round)})).sort((a,b)=>a.availableAt.localeCompare(b.availableAt));
const diagnostics=[];let at=0;
const key=board=>bookLib.boardKey(bookLib.normBoard(board));
for(const e of rows.filter(e=>e.us.role==='ghost')){
 while(at<recorded.length&&recorded[at].availableAt<e.played_at)book.record(recorded[at++]);
 const d=JSON.parse(fs.readFileSync(__dirname+'/public/'+e.id+'.json'));
 if(d.opponent.x_handle!=='tetsuoai'||d.player.x_handle!==e.enemy.x_handle)throw Error('Defense role mismatch');
 for(const r of d.rounds){
  const attacker=bookLib.publicReplayBoard(r,'you'),defender=bookLib.publicReplayBoard(r,'them');
  const known=book.lookup(3,e.enemy.x_handle,r.round),latest=known.slice().sort((a,b)=>b.lastTs-a.lastTs)[0];
  const sources=battles.filter(b=>b.round===r.round&&b.ts<e.played_at&&key(b.us)===key(defender));
  diagnostics.push({matchId:e.id,playedAt:e.played_at,afterStop:e.played_at>end,opponent:e.enemy.x_handle,result:e.us.outcome,round:r.round,attackerKnown:known.some(k=>key(k.board)===key(attacker)),latestMatches:!!latest&&key(latest.board)===key(attacker),known:known.length,attacker,defender,lastOwnSource:sources.at(-1)?{matchId:sources.at(-1).matchId,ts:sources.at(-1).ts}:null});
 }
}
const diagnosticSummary=rs=>({rounds:rs.length,known:rs.filter(r=>r.attackerKnown).length,unknown:rs.filter(r=>!r.attackerKnown).length,latestMatches:rs.filter(r=>r.latestMatches).length,matchedOwnBoard:rs.filter(r=>r.lastOwnSource).length});
const summary={first:start,logEnd:end,publicSnapshotLast:rows.at(-1).played_at,duplicates,crosscheckErrors:crosscheck,missingLogResults:rows.filter(e=>e.us.role==='attacker'&&!logIds.has(e.id)),during:section(rows.filter(e=>e.played_at<=end)),afterStop:section(rows.filter(e=>e.played_at>end)),defenseKnowledge:{during:diagnosticSummary(diagnostics.filter(r=>!r.afterStop)),afterStop:diagnosticSummary(diagnostics.filter(r=>r.afterStop)),ternquestDuring:diagnosticSummary(diagnostics.filter(r=>!r.afterStop&&r.opponent==='ternquest_com'))}};
fs.writeFileSync(__dirname+'/defense-summary.json',JSON.stringify(summary,null,2));fs.writeFileSync(__dirname+'/defense-rounds.json',JSON.stringify(diagnostics));
console.log(JSON.stringify({...summary,during:{attacks:summary.during.attacks,defenses:summary.during.defenses,ternquest:summary.during.byOpponent.ternquest_com},afterStop:{attacks:summary.afterStop.attacks,defenses:summary.afterStop.defenses,ternquest:summary.afterStop.byOpponent.ternquest_com}},null,2));
