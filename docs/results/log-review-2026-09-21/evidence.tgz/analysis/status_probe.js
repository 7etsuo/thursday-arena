'use strict';
const fs=require('fs'),Module=require('module'),path=require('path'),{isDeepStrictEqual:eq}=require('util');
const ROOT=process.env.ARENA_AUDIT_RUNTIME||require('path').join(__dirname,'runtime'),filename=ROOT+'/lib/sim.js';
let source=fs.readFileSync(filename,'utf8');
const replacements=[
 ['poisoned.push([source, unit, eff(source, kitOf(source).effect.amount)])','poisoned.push([source, unit, kitOf(source).effect.amount])'],
 ['tgt._vulnerable = (tgt._vulnerable || 0) + eff(x, ef.amount)','tgt._vulnerable = (tgt._vulnerable || 0) + ef.amount'],
];
for(const [from,to]of replacements){if(source.split(from).length!==2)throw Error('Unexpected patch site');source=source.replace(from,to);}
const mod=new Module(filename,module);mod.filename=filename;mod.paths=Module._nodeModulePaths(path.dirname(filename));mod._compile(source,filename);
const sim=mod.exports,rows=require('./battle-rows.json');let winners=0,frames=0;const changed=[];
for(const b of rows){const got=sim.simulate(b.us,b.them,b.opts),pub=JSON.parse(fs.readFileSync(__dirname+'/public/'+b.matchId+'.json')).rounds.find(r=>r.round===b.round);const winner=got.winner==='us'?'you':got.winner;winners+=winner===b.winner;frames+=eq(got.frames,pub.frames);if(winner!==b.simWinner)changed.push({matchId:b.matchId,round:b.round,opponent:b.opponent,result:b.matchResult,before:b.simWinner,after:winner,actual:b.winner,framesExact:eq(got.frames,pub.frames)});}
const out={note:'Diagnostic loaded only in memory. No application file changed. Only remove Hotfix amplification from vulnerability and venom.',battles:rows.length,winners,frames,changed};fs.writeFileSync(__dirname+'/status-probe.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
