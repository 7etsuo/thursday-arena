# September 21 logs audit evidence

Inputs: all files from the supplied logs TGZ, read separately from the live checkout.
`events.json` contains telemetry with code ID `5b818477d8cb`; `initial-book.json` is the prior supplied remote book at 05:01 UTC.
`public/` contains 1,151 completed player match details and 129 defensive match details, downloaded with GET only.
`public-history.json` and `history-page-*.json` preserve the account history, including defensive ratings.
`runtime/` is the unchanged application snapshot used for analysis.

Offline reproduction under Node 25, from this directory:

```sh
node audit.js
node decision_audit.js
node status_probe.js
node defense_audit.js
```

No command above writes runtime memory or plays a game. The status probe compiles two diagnostic string replacements in memory only. It is not a released patch. Fetch scripts perform public GETs and are not needed to reproduce saved results.

`decision_audit.js` uses shop-time captain knowledge when choosing seats; round-0 rival captains revealed in the battle are used only to score the actual outcome. Hindsight opportunities intentionally use the revealed board and are not deployable win-rate improvements.

The initial fetch hit one temporary HTTP 429 after retries; the cached follow-up fetched the missing replay. All requested details are present in the final fetch reports.
