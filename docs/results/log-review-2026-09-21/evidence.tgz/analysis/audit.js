'use strict';
const fs=require('fs'),path=require('path'),{isDeepStrictEqual:eq}=require('util');
const ROOT=process.env.ARENA_AUDIT_RUNTIME||require('path').join(__dirname,'runtime');
const sim=require(ROOT+'/lib/sim'),shop=require(ROOT+'/lib/shop_model'),bookLib=require(ROOT+'/lib/book'),target=require(ROOT+'/lib/target'),planner=require(ROOT+'/lib/planner'),catalog=require(ROOT+'/lib/catalog');
const all=require('./events.json'),drySessions=new Set(all.filter(e=>e.type==='session_start'&&e.dry).map(e=>e.session));
const events=all.filter(e=>!drySessions.has(e.session));
const initial=require('path').join(__dirname,'initial-book.json');
const book=bookLib.open(initial,{now:()=>Date.parse(events[0].ts)}),matches=new Map();
for(const e of events){
 if(!e.matchKey)continue;
 let m=matches.get(e.matchKey);if(!m){m={key:e.matchKey,events:[],battles:[]};matches.set(e.matchKey,m);}
 m.events.push(e);if(e.type==='match_start')m.start=e;
 if(e.matchId&&!e.matchId.startsWith('local_'))m.id=e.matchId;
 if(e.type==='result')m.result=e;
 if(e.type==='battle')m.battles.push(e);
}
for(const m of matches.values()){
 const file=path.join(__dirname,'public',m.id+'.json');
 if(m.id&&fs.existsSync(file))m.detail=JSON.parse(fs.readFileSync(file));
 if(m.result&&!m.detail)throw Error('Missing public replay '+m.id);
 m.handle=m.result?.opponent||m.battles.find(b=>b.handle)?.handle||m.events.find(e=>e.type==='shop'&&e.handle)?.handle||null;
}
const shopRows=[],battleRows=[],observations=[],sourceMismatches=[],learningErrors=[],modelErrors=[],frameDifferences=[];
const sourceChecks=[],sMap=new Map(),rowMap=new Map();let economyChecks=0,boardChecks=0,legalityChecks=0;
const normShop=e=>({round:e.round,gold:e.gold,board:e.board,offers:e.offers,frozen:e.offers.map(o=>!!o?.frozen),food:e.food,series:e.series,seats:e.seats,season:e.season,captain:e.captain||null,rivalCaptain:e.rivalCaptain||null,captainOffer:null,carry:e.carry||0,freeRerolls:e.freeRerolls??null,shopCosts:e.shopCosts||null,itemOffer:e.itemOffer||null,rerolls:e.rerolls||0,pendingBuff:null,nextUid:Math.max(0,...e.board.map(u=>u.uid||0))+1});
const score=w=>w==='us'||w==='you'?1:w==='draw'?.5:0;
for(const e of events){
 const m=matches.get(e.matchKey);if(!m)continue;const k=e.matchKey+':'+e.round;
 if(e.type==='shop'){
  const S=normShop(e),opts={book,season:e.season,round:e.round,handle:e.handle,prevHandle:m.start.prevHandle,seats:e.seats},T=target.build(opts);
  const expected={bookN:e.target.bookN,poolN:e.target.poolN,bookWeight:e.target.bookWeight};
  const check={ts:e.ts,matchKey:e.matchKey,round:e.round,expected,actual:T.sources,entriesExpected:e.target.entries,entriesActual:T.entries.length};
  sourceChecks.push(check);if(!eq(T.sources,expected)||T.entries.length!==e.target.entries)sourceMismatches.push(check);
  const futureTargets={};for(let r=e.round+1;r<=2;r++)futureTargets[r]=target.build({...opts,round:r,handle:e.handle||m.start.prevHandle,bookWeight:e.handle?undefined:.5});
  const row={matchKey:m.key,matchId:m.id,round:e.round,opponent:m.handle,matchResult:m.result?.result,ts:e.ts,state:S,target:T,futureTargets,bookCandidates:book.lookup(3,e.round===0?(e.handle||m.start.prevHandle):e.handle,e.round),prevHandle:m.start.prevHandle,handle:e.handle,actions:[]};
  rowMap.set(k,row);sMap.set(k,S);shopRows.push(row);
 }
 if(e.type==='act'&&e.action&&e.accepted){
  const row=rowMap.get(k),S=sMap.get(k),action=e.action;
  if(row)row.actions.push({ts:e.ts,action,reason:e.reason,value:e.value,gold:e.gold,goldLeft:e.goldLeft});
  if(S&&e.after&&e.afterPhase==='shop'&&action.type!=='pickCaptain'){
   const legal=shop.legal(S,action);legalityChecks++;
   if(legal!==true)modelErrors.push({matchId:m.id,round:e.round,action,field:'legality',error:legal});
   else{
    const pred=shop.apply(S,action);economyChecks++;
    if(pred.gold!==e.after.gold)modelErrors.push({matchId:m.id,round:e.round,action,field:'gold',pred:pred.gold,actual:e.after.gold});
    if(action.type!=='reroll'){
     boardChecks++;
     if(!shop.simUnitsOutcomes(pred).some(w=>eq(w.units,shop.simUnits(e.after))))modelErrors.push({matchId:m.id,round:e.round,action,field:'board',pred:shop.simUnitsOutcomes(pred),actual:shop.simUnits(e.after)});
    }
   }
  }
  if(e.after&&e.afterPhase==='shop')sMap.set(k,e.after);
  if(row&&action.type==='endShop'){row.finalState=S;row.goldLeft=e.goldLeft;}
 }
 if(e.type==='battle'&&e.us?.length&&m.detail){
  const r=m.detail.rounds.find(r=>r.round===e.round);if(!r)throw Error('No round '+k);
  const opts={season:3,round:e.round,seats:e.seats,ourCaptain:e.captain,theirCaptain:e.rivalCaptain};
  const us=r.you.map(u=>catalog.toSimUnit(u,3)),them=r.them.map(u=>catalog.toSimUnit(u,3)),got=sim.simulate(us,them,opts);
  let at=0;while(at<Math.max(got.frames.length,e.frames.length)&&eq(got.frames[at],e.frames[at]))at++;
  const exact=at===got.frames.length&&at===e.frames.length;
  const br={matchKey:m.key,matchId:m.id,round:e.round,ts:e.ts,opponent:m.handle,matchResult:m.result?.result,winner:e.winner,simWinner:got.winner==='us'?'you':got.winner,framesExact:exact,ourInputMatches:eq(bookLib.normBoard(us),bookLib.normBoard(e.us)),publicFramesMatch:eq(r.frames,e.frames),us,them,opts};
  if(!exact){br.frameDifference={at,got:got.frames[at],expected:e.frames[at],gotFrames:got.frames.length,expectedFrames:e.frames.length};frameDifferences.push(br);}
  const row=rowMap.get(k);if(row){row.battle=br;row.exactThem=them;row.actualUnits=us;row.framesExact=exact;row.simOptions=opts;row.battleResult=e.winner;}
  battleRows.push(br);
 }
 if(e.type==='book'){
  const b=m.battles.find(b=>b.round===e.round),r=m.detail?.rounds.find(r=>r.round===e.round);
  if(!b||!m.handle)throw Error('Missing learning context '+k);
  if(e.source==='public_replay'&&!r)throw Error('No public learning row '+k);
  const obs={season:3,handle:m.handle,round:e.round,board:e.source==='public_replay'?bookLib.publicReplayBoard(r,'them'):b.them,seats:b.seats,matchId:e.matchId,captain:b.rivalCaptain,ts:b.ts,source:e.source,matchKey:m.key};
  if(!book.record(obs))learningErrors.push({key:k,error:'empty record'});observations.push(obs);
 }
}
const completed=[...matches.values()].filter(m=>m.result),byOpponent={};
for(const m of completed){const h=m.handle;const a=byOpponent[h]||(byOpponent[h]={win:0,loss:0,draw:0,elo:0});a[m.result.result]++;a.elo+=m.result.eloDelta||0;}
const missingLearn=[],duplicateLearn=[];
for(const m of matches.values())for(const b of m.battles){
 if(!b.us.length)continue;
 const obs=observations.filter(o=>o.matchKey===m.key&&o.round===b.round);
 if(obs.length===0)missingLearn.push({key:m.key,round:b.round,opponent:m.handle,result:m.result?.result});
 if(obs.length>1)duplicateLearn.push({key:m.key,round:b.round,n:obs.length});
}
const c=rows=>rows.reduce((a,m)=>(a[m.result.result]=(a[m.result.result]||0)+1,a),{});
const summary={code:events[0].code,matches:completed.length,results:c(completed),byOpponent,first:events[0].ts,last:events.at(-1).ts,completeFullMatches:completed.filter(m=>m.battles.length===m.detail.rounds.length&&m.battles.every(b=>b.us.length)).length,battles:battleRows.length,simWinners:battleRows.filter(r=>r.winner===r.simWinner).length,simFrames:battleRows.filter(r=>r.framesExact).length,ourInputs:battleRows.filter(r=>r.ourInputMatches).length,publicFrames:battleRows.filter(r=>r.publicFramesMatch).length,shops:shopRows.length,sourceMismatches,legalityChecks,economyChecks,boardChecks,modelErrors,learning:{observations:observations.length,source:observations.reduce((a,r)=>(a[r.source]=(a[r.source]||0)+1,a),{}),missingLearn,duplicateLearn,errors:learningErrors,lossMatches:completed.filter(m=>m.result.result==='loss').length,lossRounds:observations.filter(o=>matches.get(o.matchKey).result?.result==='loss').length,finalReconstructedStats:book.stats(),finalDiskBookProvided:false},frameDifferences:frameDifferences.map(({us,them,...r})=>r),emptySeats:shopRows.filter(r=>r.finalState&&r.finalState.board.length<3).map(r=>({matchId:r.matchId,round:r.round,gold:r.goldLeft,board:r.finalState.board}))};
fs.writeFileSync(__dirname+'/shop-rows.json',JSON.stringify(shopRows));
fs.writeFileSync(__dirname+'/battle-rows.json',JSON.stringify(battleRows));
fs.writeFileSync(__dirname+'/observations.json',JSON.stringify(observations));
fs.writeFileSync(__dirname+'/reconstructed-book.json',JSON.stringify(book.data()));
fs.writeFileSync(__dirname+'/audit-summary.json',JSON.stringify(summary,null,2));
console.log(JSON.stringify({...summary,byOpponent:undefined,frameDifferences:summary.frameDifferences.map(r=>({matchId:r.matchId,round:r.round,opponent:r.opponent,winner:r.winner,simWinner:r.simWinner,at:r.frameDifference.at,got:r.frameDifference.got?.caption,expected:r.frameDifference.expected?.caption})),sourceMismatches:sourceMismatches.length,modelErrors:modelErrors.length,emptySeats:summary.emptySeats.length},null,2));
