'use strict';
const fs=require('fs'),path=require('path');
const ids=JSON.parse(fs.readFileSync(path.join(__dirname,process.argv[2]||'match-ids.json'))),base=__dirname;
let next=0,done=0; const failures=[];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function worker(){
  while(next<ids.length){
    const id=ids[next++],file=path.join(base,'public',id+'.json');
    if(fs.existsSync(file)){done++;continue;}
    for(let attempt=0;attempt<4;attempt++){
      try{
        const res=await fetch('https://thursdayarena.com/api/public/v1/matches/'+id,{signal:AbortSignal.timeout(20000)});
        if(res.status===429){await sleep(Math.max(2000,(Number(res.headers.get('retry-after'))||2)*1000));if(attempt===3)throw Error('HTTP 429');continue;}
        if(!res.ok)throw Error('HTTP '+res.status);
        const d=await res.json();if(d.id!==id||!Array.isArray(d.rounds))throw Error('Invalid match response');
        fs.writeFileSync(file,JSON.stringify(d)+'\n');break;
      }catch(e){if(attempt===3)failures.push({id,error:e.message});else await sleep(1000);}
    }
    done++;if(done%100===0)console.log(JSON.stringify({done,total:ids.length,failures:failures.length}));
    await sleep(150);
  }
}
Promise.all([worker(),worker()]).then(()=>{
 const report={total:ids.length,downloaded:ids.length-failures.length,failures};
 fs.writeFileSync(path.join(base,process.argv[3]||'fetch-report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
});
