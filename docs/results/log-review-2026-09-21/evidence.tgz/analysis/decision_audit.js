'use strict';
const fs=require('fs'),ROOT=process.env.ARENA_AUDIT_RUNTIME||require('path').join(__dirname,'runtime');
const sim=require(ROOT+'/lib/sim'),shop=require(ROOT+'/lib/shop_model'),planner=require(ROOT+'/lib/planner'),book=require(ROOT+'/lib/book');
const rows=require('./shop-rows.json').filter(r=>r.battle&&r.finalState);
const score=w=>w==='us'||w==='you'?1:w==='draw'?.5:0;
const key=board=>book.boardKey(book.normBoard(board));
const predictions=[],seating=[],stopChecks=[],neutralUpgrades=[],hindsightMoves=[];
for(const r of rows){
 const actual=key(r.exactThem),known=r.bookCandidates,newest=Math.max(0,...known.map(k=>k.lastTs)),bk=known.map(k=>({...k,key:key(k.board)}));
 const policies={frequency:bk,latest:bk.map(k=>({...k,n:k.lastTs===newest?k.n:0}))};
 const probs={};for(const [p,ks] of Object.entries(policies)){
  const total=ks.reduce((s,k)=>s+k.n,0),matching=ks.filter(k=>k.key===actual).reduce((s,k)=>s+k.n,0),top=ks.length?ks.reduce((a,b)=>b.n>a.n?b:a):null;
  probs[p]={mass:total?matching/total:0,top:!!top&&top.key===actual};
 }
 predictions.push({matchId:r.matchId,round:r.round,opponent:r.opponent,result:r.matchResult,known:known.length,covered:bk.some(k=>k.key===actual),probs});
 if(!r.framesExact)continue;
 // The rival captain in a battle is revealed AFTER R0 shopping. Use shop-time captain knowledge for decisions.
 const opts={...r.simOptions,ourCaptain:r.state.captain,theirCaptain:r.state.rivalCaptain,utility:planner.utility(r.round,r.state.series)},plain={...r.simOptions,utility:{win:1,draw:.5,loss:0}},targetPlain={...opts,utility:plain.utility};
 const expected=planner.evaluate(r.actualUnits,r.target,opts),actualOutcome=sim.outcome(expected.order,r.exactThem,r.simOptions);
 const oracle=planner.evaluate(r.actualUnits,[{board:r.exactThem,weight:1}],plain);
 seating.push({matchId:r.matchId,round:r.round,opponent:r.opponent,result:r.matchResult,winner:r.battleResult,targetScore:expected.score,chosenScore:score(actualOutcome),observedScore:score(r.battleResult),oracleScore:oracle.score,oracleOrder:oracle.order.map(u=>u.name),gold:r.goldLeft});
 const candidates=(r.goldLeft>=1||score(r.battleResult)<1)?planner.singleMoves(r.finalState):[];
 let stopBest=expected.score,stopMove=null,stopActual=null,neutralBest=planner.evaluate(r.actualUnits,r.target,targetPlain).score,neutralMove=null,neutralOffense=null,hindsightBest=oracle.score,hindsightMove=null;
 const neutralBase=neutralBest;
 for(const move of candidates){
  let st=r.finalState;for(const a of move.actions)st=shop.apply(st,a);
  const outcomes=shop.simUnitsOutcomes(st);
  let v=0,nv=0,hv=0,av=0;
  for(const w of outcomes){
   if(r.goldLeft>=1&&r.round>0){
    const choice=planner.evaluate(w.units,r.target,opts);v+=w.p*choice.score;
    av+=w.p*score(sim.outcome(choice.order,r.exactThem,r.simOptions));
    if(opts.utility.draw!==.5)nv+=w.p*planner.evaluate(w.units,r.target,targetPlain).score;
   }
   if(score(r.battleResult)<1)hv+=w.p*planner.evaluate(w.units,[{board:r.exactThem,weight:1}],plain).score;
  }
  if(r.goldLeft>=1&&r.round>0){
   if(v>stopBest+1e-8){stopBest=v;stopMove=move.actions;stopActual=av;}
   if(opts.utility.draw!==.5&&v>=expected.score-1e-8&&nv>neutralBest+1e-8){neutralBest=nv;neutralMove=move.actions;neutralOffense=v;}
  }
  if(score(r.battleResult)<1&&hv>hindsightBest+1e-8){hindsightBest=hv;hindsightMove=move.actions;}
 }
 if(r.goldLeft>=1&&r.round>0)stopChecks.push({matchId:r.matchId,round:r.round,opponent:r.opponent,result:r.matchResult,gold:r.goldLeft,base:expected.score,best:stopBest,move:stopMove,actualAfterMove:stopActual,actual:score(r.battleResult)});
 if(neutralMove)neutralUpgrades.push({matchId:r.matchId,round:r.round,opponent:r.opponent,result:r.matchResult,gold:r.goldLeft,series:r.state.series,baseOffense:expected.score,newOffense:neutralOffense,baseNeutral:neutralBase,newNeutral:neutralBest,actions:neutralMove});
 if(hindsightMove)hindsightMoves.push({matchId:r.matchId,round:r.round,opponent:r.opponent,result:r.matchResult,gold:r.goldLeft,actual:score(r.battleResult),seatingOnly:oracle.score,afterMove:hindsightBest,actions:hindsightMove});
}
function subset(rs){return {n:rs.length,known:rs.filter(r=>r.known).length,covered:rs.filter(r=>r.covered).length,latest:rs.filter(r=>r.probs.latest.top).length,frequency:rs.filter(r=>r.probs.frequency.top).length,latestMass:rs.reduce((s,r)=>s+r.probs.latest.mass,0)/(rs.length||1),frequencyMass:rs.reduce((s,r)=>s+r.probs.frequency.mass,0)/(rs.length||1)};}
const predictionSummary={all:subset(predictions),later:subset(predictions.filter(r=>r.round>0)),laterTernquest:subset(predictions.filter(r=>r.round>0&&r.opponent==='ternquest_com')),laterLosses:subset(predictions.filter(r=>r.round>0&&r.result==='loss')),first:subset(predictions.filter(r=>r.round===0))};
const seatingRescues=seating.filter(r=>r.oracleScore>r.observedScore),rescoreDifferent=seating.filter(r=>r.chosenScore!==r.observedScore),stopImprovements=stopChecks.filter(r=>r.move);
const summary={rows:rows.length,frameExactRows:seating.length,predictionSummary,seatingRescues:seatingRescues.length,seatingRescuesInLostMatches:seatingRescues.filter(r=>r.result==='loss').length,targetReseatDifferent:rescoreDifferent.length,stopChecks:stopChecks.length,stopImprovements,neutralUpgrades,hindsightMoves};
fs.writeFileSync(__dirname+'/decision-summary.json',JSON.stringify(summary,null,2));
fs.writeFileSync(__dirname+'/predictions.json',JSON.stringify(predictions));fs.writeFileSync(__dirname+'/seating.json',JSON.stringify(seating));fs.writeFileSync(__dirname+'/stop-checks.json',JSON.stringify(stopChecks));
console.log(JSON.stringify({...summary,stopImprovements:stopImprovements.length,neutralUpgrades:neutralUpgrades.length,hindsightMoves:hindsightMoves.length},null,2));
