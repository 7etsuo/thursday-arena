'use strict';
const fs=require('fs');
const start='2026-09-21T07:17:54.651Z';
async function main(){
 let page=require('./tetsuoai-recent.json'),rows=[],pages=0;
 while(true){
  rows.push(...page.data);pages++;
  fs.writeFileSync(__dirname+'/history-page-'+pages+'.json',JSON.stringify(page));
  if(!page.next_cursor||!page.data.length||page.data.at(-1).played_at<start)break;
  const url='https://thursdayarena.com/api/public/v1/matches?'+new URLSearchParams({x_handle:'tetsuoai',limit:'100',cursor:page.next_cursor});
  const res=await fetch(url,{signal:AbortSignal.timeout(20000)});
  if(!res.ok)throw Error('HTTP '+res.status);
  page=await res.json();
  await new Promise(r=>setTimeout(r,150));
 }
 rows=[...new Map(rows.map(r=>[r.id,r])).values()].sort((a,b)=>a.played_at.localeCompare(b.played_at));
 fs.writeFileSync(__dirname+'/public-history.json',JSON.stringify(rows));
 console.log(JSON.stringify({pages,matches:rows.length,first:rows[0]?.played_at,last:rows.at(-1)?.played_at}));
}
main().catch(e=>{console.error(e);process.exitCode=1;});
